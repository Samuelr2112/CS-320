import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        taskService.addTask(task);
        assertNotNull(taskService.getTask("1"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task1 = new Task("1", "TaskName", "TaskDescription");
        Task task2 = new Task("1", "AnotherTaskName", "AnotherTaskDescription");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        taskService.addTask(task);
        taskService.updateTaskName("1", "NewTaskName");
        assertEquals("NewTaskName", taskService.getTask("1").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        taskService.addTask(task);
        taskService.updateTaskDescription("1", "NewTaskDescription");
        assertEquals("NewTaskDescription", taskService.getTask("1").getDescription());
    }
}
