import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @Test
    void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        service.addAppointment(appointment);
        assertNotNull(service.getAppointment("1234567890"));
    }

    @Test
    void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment1 = new Appointment("1234567890", futureDate, "Description");
        Appointment appointment2 = new Appointment("1234567890", futureDate, "Another Description");
        service.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        service.addAppointment(appointment);
        service.deleteAppointment("1234567890");
        assertNull(service.getAppointment("1234567890"));
    }

    @Test
    void testDeleteNonExistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("nonexistentID");
        });
    }
}
