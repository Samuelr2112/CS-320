import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        assertEquals("1", task.getTaskId());
        assertEquals("TaskName", task.getName());
        assertEquals("TaskDescription", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "TaskName", "TaskDescription");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "TaskName", "TaskDescription");
        });
    }

    @Test
    public void testInvalidTaskName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "TaskDescription");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "ThisNameIsWayTooLongForTheTaskNameField", "TaskDescription");
        });
    }

    @Test
    public void testInvalidTaskDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "TaskName", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "TaskName", "ThisDescriptionIsWayTooLongForTheDescriptionFieldWhichHasA50CharacterLimit");
        });
    }

    @Test
    public void testSetName() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        task.setName("NewTaskName");
        assertEquals("NewTaskName", task.getName());
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("ThisNameIsWayTooLongForTheTaskNameField");
        });
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("1", "TaskName", "TaskDescription");
        task.setDescription("NewTaskDescription");
        assertEquals("NewTaskDescription", task.getDescription());
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("ThisDescriptionIsWayTooLongForTheDescriptionFieldWhichHasA50CharacterLimit");
        });
    }
}
